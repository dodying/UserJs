#coding=utf-8
import os
import cv2
import shutil

path = {'aj': 'Applejack', 'fs': 'Fluttershy', 'pp': 'Pinkie Pie', 'rd': 'Rainbow Dash', 'ra': 'Rarity', 'ts': 'Twilight Sparkle'}

while True:
  dir = os.listdir('E:\\Desktop\\riddle')
  for i in dir:
    if os.path.isfile(i) and i.find('jpg') > -1:
      break
  img_rgb = cv2.imread(i)
  cv2.imshow('Detected',img_rgb)
  key = cv2.waitKey(0)
  cv2.destroyAllWindows()
  if key != 13:
    key = chr(key)
    _input = key + raw_input('AJ FS PP RD RA TS: %s' %key)
    _path = path[_input]
  print i + ' >> ' + _path + '/' + i
  shutil.move(i, _path + '/' + i)
